# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: features/login.feature.spec.js >> Login >> Login com utilizador válido
- Location: .features-gen/features/login.feature.spec.js:6:7

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator: getByTestId('page-title')
Expected: "My account"
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toHaveText" getByTestId('page-title') with timeout 10000ms
  - waiting for getByTestId('page-title')
    - waiting for "https://practicesoftwaretesting.com/account" navigation to finish...
    - navigated to "https://practicesoftwaretesting.com/account"

```

```yaml
- main:
  - img "Icon for practicesoftwaretesting.com"
  - heading "practicesoftwaretesting.com" [level=1]
  - heading "Performing security verification" [level=2]
  - paragraph: This website uses a security service to protect against malicious bots. This page is displayed while the website verifies you are not a bot.
- contentinfo:
  - text: "Ray ID:"
  - code: a55d05823faa4f76
  - text: Performance and Security by
  - link "Cloudflare, opens in a new tab":
    - /url: https://www.cloudflare.com?utm_source=challenge&utm_campaign=m
    - text: Cloudflare
  - link "Privacy, opens in a new tab":
    - /url: https://www.cloudflare.com/privacypolicy/
    - text: Privacy
```

# Test source

```ts
  1  | import { expect } from '@playwright/test';
  2  | import { createBdd } from 'playwright-bdd';
  3  | import { LoginPage } from '../pages/LoginPage';
  4  | import { AccountPage } from '../pages/AccountPage';
  5  | 
  6  | const { Given, When, Then } = createBdd();
  7  | 
  8  | Given('que estou na página de login', async ({ page }) => {
  9  |     const loginPage = new LoginPage(page);
  10 |     await loginPage.abrir();
  11 | });
  12 | 
  13 | When('faço login com {string} e {string}', async ({ page }, email: string, password: string) => {
  14 |     const loginPage = new LoginPage(page);
  15 |     await loginPage.fazerLogin(email, password);
  16 | });
  17 | 
  18 | Then('vejo a página {string}', async ({ page }, titulo: string) => {
  19 |     const accountPage = new AccountPage(page);
> 20 |     await expect(accountPage.titulo).toHaveText(titulo);
     |                                      ^ Error: expect(locator).toHaveText(expected) failed
  21 | });
  22 | 
  23 | Then('vejo a mensagem de erro {string}', async ({ page }, mensagem: string) => {
  24 |     const loginPage = new LoginPage(page);
  25 |     await expect(loginPage.mensagemErro).toContainText(mensagem);
  26 | });
```