// Generated from: features/login.feature
import { test } from "playwright-bdd";

test.describe('Login', () => {

  test('Login com utilizador válido', async ({ Given, When, Then, page }) => { 
    await Given('que estou na página de login', null, { page }); 
    await When('faço login com "customer2@practicesoftwaretesting.com" e "welcome01"', null, { page }); 
    await Then('vejo a página "My account"', null, { page }); 
  });

  test('Login com password errada', async ({ Given, When, Then, page }) => { 
    await Given('que estou na página de login', null, { page }); 
    await When('faço login com "utilizador-inexistente@teste.com" e "password-errada"', null, { page }); 
    await Then('vejo a mensagem de erro "Invalid email or password"', null, { page }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('features/login.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":6,"pickleLine":7,"tags":[],"steps":[{"pwStepLine":7,"gherkinStepLine":8,"keywordType":"Context","textWithKeyword":"Dado que estou na página de login","stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":9,"keywordType":"Action","textWithKeyword":"Quando faço login com \"customer2@practicesoftwaretesting.com\" e \"welcome01\"","stepMatchArguments":[{"group":{"start":15,"value":"\"customer2@practicesoftwaretesting.com\"","children":[{"start":16,"value":"customer2@practicesoftwaretesting.com","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":57,"value":"\"welcome01\"","children":[{"start":58,"value":"welcome01","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":9,"gherkinStepLine":10,"keywordType":"Outcome","textWithKeyword":"Então vejo a página \"My account\"","stepMatchArguments":[{"group":{"start":14,"value":"\"My account\"","children":[{"start":15,"value":"My account","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":12,"pickleLine":12,"tags":[],"steps":[{"pwStepLine":13,"gherkinStepLine":13,"keywordType":"Context","textWithKeyword":"Dado que estou na página de login","stepMatchArguments":[]},{"pwStepLine":14,"gherkinStepLine":14,"keywordType":"Action","textWithKeyword":"Quando faço login com \"utilizador-inexistente@teste.com\" e \"password-errada\"","stepMatchArguments":[{"group":{"start":15,"value":"\"utilizador-inexistente@teste.com\"","children":[{"start":16,"value":"utilizador-inexistente@teste.com","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":52,"value":"\"password-errada\"","children":[{"start":53,"value":"password-errada","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":15,"gherkinStepLine":15,"keywordType":"Outcome","textWithKeyword":"Então vejo a mensagem de erro \"Invalid email or password\"","stepMatchArguments":[{"group":{"start":24,"value":"\"Invalid email or password\"","children":[{"start":25,"value":"Invalid email or password","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
]; // bdd-data-end