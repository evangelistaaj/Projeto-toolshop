# Toolshop BDD: Playwright + playwright-bdd

Automação do `login.feature` e do `registo.feature` seguindo a skill `toolshop-bdd-playwright`.

## Estrutura

```
features/*.feature          cenários em Gherkin (PT)
steps/fixtures.ts           fixtures: ctx (estado do cenário), api, page objects
steps/login.steps.ts        step definitions do login
steps/registo.steps.ts      step definitions do registo
pages/LoginPage.ts          página /auth/login
pages/RegistoPage.ts        página /auth/register
pages/PaginaComum.ts        elementos comuns (título da página)
support/ToolshopApi.ts      criação de contas via API (POST /users/register)
support/dadosDeTeste.ts     dados de utilizador válidos e únicos (API e UI)
playwright.config.ts
```

## Como correr

```bash
npm install
npx playwright install chromium
npm run check     # gera os testes e valida os tipos, sem abrir o browser
npx playwright show-report
```

### Contra a Toolshop local (recomendado)

O site público é partilhado e bloqueia quem faz muitos registos e logins. Na tua máquina, não há limites.

1. Arranca a Toolshop com Docker (instruções completas no README do repositório):
   ```bash
   git clone https://github.com/testsmith-io/practice-software-testing.git
   cd practice-software-testing
   docker compose -f docker-compose.prod.yml up --pull missing -d
   ```
   Segundo o README do repositório, a aplicação fica em `localhost:4200` e a API em `localhost:8091` (confirmar).
2. Corre todos os cenários:
   ```bash
   # bash / macOS / Linux
   BASE_URL=http://localhost:4200 API_URL=http://localhost:8091 npm test
   ```
   ```powershell
   # Windows PowerShell
   $env:BASE_URL="http://localhost:4200"; $env:API_URL="http://localhost:8091"; npm test
   ```
3. Para repor a base de dados:
   ```bash
   docker exec -it pst-laravel-api-1 php artisan migrate:fresh --seed
   ```

### Contra o site público

```bash
npm run test:publico   # sem os cenários @so-local
npm run test:ci        # sem @so-local nem @sem-ci (o mínimo de tráfego)
```

Por omissão usa `https://practicesoftwaretesting.com` e `https://api.practicesoftwaretesting.com`.

## Tags

| Tag | Significado |
|---|---|
| `@sem-ci` | Cria uma conta. Fora da CI para não encher a demo pública. |
| `@so-local` | Só corre contra a Toolshop local: provoca falhas de login ou bloqueios de conta. Se for corrido contra outro endereço, é saltado automaticamente. |

## Decisões

- **Seletores:** os `data-test` (`email`, `password`, `login-submit`, `login-error`, `page-title`) foram confirmados no código-fonte da Toolshop (repositório testsmith-io/practice-software-testing, pasta `sprint5`).
- **Conta registada:** é criada via API, não pelo formulário. A password é aleatória porque a API rejeita passwords que aparecem em fugas de dados conhecidas.
- **Estado entre passos:** a conta criada fica em `ctx.conta`, uma fixture por cenário. Não há variáveis globais.
- **Bloqueio de conta:** à 3.ª tentativa falhada, a Toolshop bloqueia a conta e recusa as seguintes, mesmo com a password certa. Por isso os testes de password errada são `@so-local` e usam sempre uma conta acabada de criar, nunca as contas de demonstração partilhadas.
- **Login espera pela resposta da API:** o `LoginPage.fazerLogin` só termina quando a API responde. Assim podem fazer-se várias tentativas seguidas sem corridas.
- **Morada no registo:** ao preencher país, código postal e número da porta, a Toolshop pesquisa a morada e pode reescrever rua, cidade e distrito. O `RegistoPage` espera que a pesquisa termine antes de escrever esses campos e confirma que os valores ficaram.
