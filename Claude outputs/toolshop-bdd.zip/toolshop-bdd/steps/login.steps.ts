import { expect } from '@playwright/test';
import type { Conta } from '../support/ToolshopApi';
import { Given, When, Then, type Contexto } from './fixtures';

// ---------- Contexto (Dado) ----------

Given('que tenho uma conta registada', async ({ api, ctx }) => {
  // Criada via API: não depende do formulário de registo e é muito mais rápida.
  ctx.conta = await api.criarConta();
});

Given('que estou na página de login', async ({ loginPage }) => {
  await loginPage.abrir();
});

// ---------- Ações (Quando) ----------

function contaDoCenario(ctx: Contexto): Conta {
  if (!ctx.conta) {
    throw new Error('Nenhuma conta registada neste cenário. Falta o passo "Dado que tenho uma conta registada"?');
  }
  return ctx.conta;
}

When('faço login com a conta registada', async ({ loginPage, ctx }) => {
  const conta = contaDoCenario(ctx);
  await loginPage.fazerLogin(conta.email, conta.password);
});

When(
  'faço login com a conta registada e a password {string}',
  async ({ loginPage, ctx }, password: string) => {
    await loginPage.fazerLogin(contaDoCenario(ctx).email, password);
  },
);

// Cada falha soma 1 tentativa; ao chegar a 3, a Toolshop recusa as seguintes,
// mesmo com a password certa (sprint5/API/app/Services/UserService.php).
When(
  'falho o login {int} vezes com a conta registada',
  async ({ loginPage, ctx }, vezes: number) => {
    const conta = contaDoCenario(ctx);
    for (let i = 0; i < vezes; i++) {
      await loginPage.fazerLogin(conta.email, `${conta.password}-errada`);
      await expect(loginPage.mensagemDeErro).toHaveText('Invalid email or password');
    }
  },
);

When('faço login com {string} e {string}', async ({ loginPage }, email: string, password: string) => {
  await loginPage.fazerLogin(email, password);
});

// ---------- Resultados (Então) ----------

// Passo genérico: compara o título principal da página (data-test="page-title").
Then('vejo a página {string}', async ({ paginaComum }, titulo: string) => {
  await expect(paginaComum.titulo).toHaveText(titulo);
});

// Por agora só existe a mensagem de erro do login. Se outra página precisar
// deste passo, generalizar o locator em vez de duplicar o passo.
Then('vejo a mensagem de erro {string}', async ({ loginPage }, mensagem: string) => {
  await expect(loginPage.mensagemDeErro).toHaveText(mensagem);
});
