import { test as base, createBdd } from 'playwright-bdd';
import { LoginPage } from '../pages/LoginPage';
import { PaginaComum } from '../pages/PaginaComum';
import { RegistoPage } from '../pages/RegistoPage';
import { ToolshopApi, type Conta } from '../support/ToolshopApi';

/** Estado partilhado entre os passos de um cenário (nunca usar variáveis globais). */
export type Contexto = {
  conta?: Conta;
  precoMin?: number;
  precoMax?: number;
};

type Fixtures = {
  ctx: Contexto;
  api: ToolshopApi;
  loginPage: LoginPage;
  paginaComum: PaginaComum;
  registoPage: RegistoPage;
  protecaoSoLocal: void;
};

export const test = base.extend<Fixtures>({
  // Corre automaticamente antes de cada cenário. Um cenário @so-local contra o
  // site público é saltado: evita bloqueios e contas bloqueadas na demo partilhada.
  protecaoSoLocal: [
    async ({ baseURL }, use, testInfo) => {
      const ambienteLocal = /\/\/(localhost|127\.0\.0\.1)(:|\/|$)/.test(baseURL ?? '');
      testInfo.skip(
        testInfo.tags.includes('@so-local') && !ambienteLocal,
        'Cenário @so-local: só corre contra a Toolshop local (BASE_URL em localhost).',
      );
      await use();
    },
    { auto: true },
  ],

  ctx: async ({}, use) => {
    await use({});
  },

  api: async ({ playwright }, use) => {
    const request = await playwright.request.newContext({
      baseURL: process.env.API_URL ?? 'https://api.practicesoftwaretesting.com',
    });
    await use(new ToolshopApi(request));
    await request.dispose();
  },

  loginPage: async ({ page }, use) => {
    await use(new LoginPage(page));
  },

  paginaComum: async ({ page }, use) => {
    await use(new PaginaComum(page));
  },

  registoPage: async ({ page }, use) => {
    await use(new RegistoPage(page));
  },
});

export const { Given, When, Then } = createBdd(test);
