import { expect } from '@playwright/test';
import { gerarDadosDeUtilizador } from '../support/dadosDeTeste';
import { Given, When, Then } from './fixtures';

// ---------- Contexto (Dado) ----------

Given('que estou na página de registo', async ({ registoPage }) => {
  await registoPage.abrir();
});

// ---------- Ações (Quando) ----------

When('registo um novo utilizador com dados válidos', async ({ registoPage, ctx }) => {
  const dados = gerarDadosDeUtilizador();
  await registoPage.registar(dados);
  // Guardado para um passo seguinte poder usar a conta (ex.: fazer login com ela).
  ctx.conta = { email: dados.email, password: dados.password };
});

// ---------- Resultados (Então) ----------

Then('sou redirecionado para a página de login', async ({ page, loginPage }) => {
  // Após o registo, a Toolshop recarrega a página em /auth/login.
  await expect(page).toHaveURL(/\/auth\/login$/);
  await expect(loginPage.botaoEntrar).toBeVisible();
});
