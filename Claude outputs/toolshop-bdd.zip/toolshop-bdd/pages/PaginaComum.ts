import { type Locator, type Page } from '@playwright/test';

/**
 * Elementos comuns a várias páginas da Toolshop.
 * O título principal usa data-test="page-title"
 * (ex.: "My account" em sprint5/UI/src/app/account/overview/overview.component.html).
 */
export class PaginaComum {
  readonly titulo: Locator;

  constructor(page: Page) {
    this.titulo = page.getByTestId('page-title');
  }
}
