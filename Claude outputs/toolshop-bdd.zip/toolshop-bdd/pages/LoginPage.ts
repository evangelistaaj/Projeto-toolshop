import { type Locator, type Page } from '@playwright/test';

/**
 * Página de login da Toolshop (/auth/login).
 * Seletores confirmados em sprint5/UI/src/app/auth/login/login.component.html.
 */
export class LoginPage {
  readonly campoEmail: Locator;
  readonly campoPassword: Locator;
  readonly botaoEntrar: Locator;
  readonly mensagemDeErro: Locator;

  constructor(private readonly page: Page) {
    this.campoEmail = page.getByTestId('email');
    this.campoPassword = page.getByTestId('password');
    this.botaoEntrar = page.getByTestId('login-submit');
    this.mensagemDeErro = page.getByTestId('login-error');
  }

  async abrir(): Promise<void> {
    await this.page.goto('/auth/login');
    await this.campoEmail.waitFor();
  }

  /**
   * Preenche e submete o formulário e espera pela resposta da API de login.
   * Esperar pela resposta (e não pela mensagem no ecrã) é o que permite
   * submeter várias vezes seguidas sem corridas: depois da 1.ª falha, a
   * mensagem de erro já está visível e não serviria de sinal.
   */
  async fazerLogin(email: string, password: string): Promise<void> {
    await this.campoEmail.fill(email);
    await this.campoPassword.fill(password);
    const resposta = this.page.waitForResponse(
      (r) => r.url().includes('/users/login') && r.request().method() === 'POST',
    );
    await this.botaoEntrar.click();
    await resposta;
  }
}
